package client;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import entity.Type;
import entity.Watch;
import exception.TypeNotFoundException;
import exception.TypeServiceException;
import service.TypeService;
import service.WatchService;
import service.Impl.TypeServiceImpl;
import service.Impl.WatchServiceImpl;

public class AppRunner {
	private static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {

		boolean doExit = false;

		TypeService type = new TypeServiceImpl();
		WatchService watch = new WatchServiceImpl();

		do {
			displayMenu();

			System.out.print("Enter preferred choice - ");
			int userInput = sc.nextInt();
			sc.nextLine();

			switch (userInput) {
			case 1:
				Type insertType = askTypeDetails();

				try {
					type.addType(insertType);
				} catch (TypeServiceException | SQLException e) {
					System.out.println(e.getMessage());
				}

				break;

			case 2:

				int typeId = askTypeId();

				try {
					type.isTypeValid(typeId);

					watch.addWatch(typeId);
				} catch (TypeNotFoundException e) {
					System.out.println(e.getMessage());
				} catch (SQLException e) {
					e.printStackTrace();
				}

				break;

			case 3:

				ArrayList<Watch> watches = null;
				try {
					watches = watch.getAllWatches();
				} catch (SQLException e) {
					e.printStackTrace();
				}

				ArrayList<Watch> sortedWatches;
				try {
					sortedWatches = watch.sortWatches(watches);
					displayWatches(sortedWatches);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				
				
				break;

			case 4:

//				int typeIdToDelete = askTypeId();
//
//				try {
//					type.isTypeValid(typeId);
//
//					type.deleteType(typeIdToDelete);
//				} catch (TypeNotFoundException e) {
//					System.out.println(e.getMessage());
//				} catch (SQLException e) {
//					e.printStackTrace();
//				}
				break;

			case 5:
				System.out.println("Exiting...");
				doExit = true;
			}

		} while (!doExit);

		sc.close();
	}

	private static void displayWatches(ArrayList<Watch> watches) {
		watches.forEach((i) -> System.out.println("Watch id: " + i.getId() + ", Model number: " + i.getModelNumber()
				+ ", Price: " + i.getPrice() + ", Type Id: " + i.getTypeId()));
	}

	private static String askTypeName() {
		System.out.print("Enter type name - ");
		return sc.nextLine();
	}

	private static int askTypeId() {
		System.out.print("Enter type id - ");
		int id = sc.nextInt();
		sc.nextLine();
		return id;
	}

	private static Type askTypeDetails() {
		return new Type(askTypeId(), askTypeName());
	}

	private static void displayMenu() {
		System.out.println("-----------------------------------");
		System.out.println("1. Add type");
		System.out.println("2. Add watch");
		System.out.println("3. Sort all watches based on price");
		System.out.println("4. Delete particular type");
	}
}