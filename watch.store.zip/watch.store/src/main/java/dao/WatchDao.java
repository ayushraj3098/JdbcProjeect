package dao;

import java.sql.SQLException;
import java.util.ArrayList;

import entity.Watch;

public interface WatchDao {

	void addWatch(int typeId, int watchId, String modelNumber, float price) throws SQLException;
	
	ArrayList<Watch> getAllWatches() throws SQLException;
}
