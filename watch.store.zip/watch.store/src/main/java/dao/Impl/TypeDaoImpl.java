package dao.Impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import dao.TypeDao;
import entity.Type;
import exception.TypeDaoException;
import exception.TypeNotFoundException;
import utility.DBConnection;

public class TypeDaoImpl implements TypeDao {

	DBConnection obj = new DBConnection();

	@Override
	public boolean addWatchType(Type type) throws SQLException, TypeDaoException {

		Connection conn = null;
		Statement s = null;

		try {
			conn = obj.getConnection();
			s = conn.createStatement();
			String insertQuery = "INSERT INTO TYPE VALUES(" + type.getId() + ", '" + type.getName() + "' )";
			int result = s.executeUpdate(insertQuery);

			if (result != 1) {
				throw new TypeDaoException();
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			throw new SQLException();
		} finally {
			obj.closeConnection(conn);
			s.close();
		}

		return false;
	}

	@Override
	public boolean isTypeValid(int typeId) throws SQLException, TypeNotFoundException {
		Connection conn = null;
		Statement s = null;
		ResultSet rs = null;

		try {
			conn = obj.getConnection();
			s = conn.createStatement();

			String searchQuery = "SELECT * FROM type where id = " + typeId + "";
			rs = s.executeQuery(searchQuery);

			if (!rs.next()) {
				throw new TypeNotFoundException("Type does not exist");
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return true;
	}

}
