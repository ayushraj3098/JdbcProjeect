package dao.Impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import dao.WatchDao;
import entity.Watch;
import utility.DBConnection;

public class WatchDaoImpl implements WatchDao {

	DBConnection obj = new DBConnection();

	@Override
	public void addWatch(int typeId, int watchId, String modelNumber, float price) throws SQLException {
		Connection conn = null;
		Statement s = null;

		try {
			conn = obj.getConnection();
			s = conn.createStatement();

			String insertQuery = "INSERT INTO WATCH VALUES(" + watchId + ", '" + modelNumber + "', " + price + ", "
					+ typeId + ")";

			s.executeUpdate(insertQuery);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			s.close();
			obj.closeConnection(conn);
		}

	}

	@Override
	public ArrayList<Watch> getAllWatches() throws SQLException {
		Connection conn = null;
		Statement s = null;
		ArrayList<Watch> watchList = new ArrayList<>();
		ResultSet rs = null;

		try {
			conn = obj.getConnection();
			s = conn.createStatement();

			String getQuery = "SELECT * FROM WATCH";
			rs = s.executeQuery(getQuery);

			while (rs.next()) {
				watchList.add(new Watch(rs.getInt("id"), rs.getString("modelnumber"), rs.getFloat("price"),
						rs.getInt("typeid")));
				System.out.println("times");
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return watchList;
	}

}
