package dao;

import java.sql.SQLException;

import entity.Type;
import exception.TypeDaoException;
import exception.TypeNotFoundException;

public interface TypeDao {
	boolean addWatchType(Type type) throws SQLException, TypeDaoException;
	
	boolean isTypeValid(int typeId) throws SQLException, TypeNotFoundException;
}
