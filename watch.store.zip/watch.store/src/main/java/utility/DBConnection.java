package utility;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

	private static final String USERNAME = "root";
	private static final String PASSWORD = "Bikku@3098mlmrml";
	private static final String URL = " jdbc:mysql://localhost:3306/watchStore";

	public Connection getConnection() {
		Connection connection = null;

		try {
			connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return connection;
	}

	public void closeConnection(Connection connection) {
		if (connection != null) {
			try {
				connection.close();
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}
	}
}