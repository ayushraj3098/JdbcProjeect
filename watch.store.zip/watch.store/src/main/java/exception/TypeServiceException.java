package exception;

public class TypeServiceException extends ApplicationException{

}
