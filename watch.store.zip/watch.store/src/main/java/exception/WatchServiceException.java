package exception;

public class WatchServiceException extends ApplicationException{

}
