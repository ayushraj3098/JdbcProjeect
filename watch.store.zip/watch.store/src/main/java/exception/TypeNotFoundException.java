package exception;

public class TypeNotFoundException extends ApplicationException {
	public TypeNotFoundException(String message) {
		super(message);
	}
}
