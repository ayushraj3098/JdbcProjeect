package exception;

public class WatchDaoException extends ApplicationException{

}
