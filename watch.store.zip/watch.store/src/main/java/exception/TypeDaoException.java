package exception;

public class TypeDaoException extends ApplicationException{

}
