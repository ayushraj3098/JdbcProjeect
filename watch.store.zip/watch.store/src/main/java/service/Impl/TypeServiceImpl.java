package service.Impl;

import java.sql.SQLException;

import dao.TypeDao;
import dao.Impl.TypeDaoImpl;
import entity.Type;
import exception.TypeDaoException;
import exception.TypeNotFoundException;
import exception.TypeServiceException;
import service.TypeService;

public class TypeServiceImpl implements TypeService {

	TypeDao typeObj = new TypeDaoImpl();

	@Override
	public boolean addType(Type type) throws SQLException, TypeServiceException {
		try {
			typeObj.addWatchType(type);
			return true;
		} catch (SQLException e) {
			throw new SQLException();
		} catch (TypeDaoException e) {
			throw new TypeServiceException();
		}
	}

	@Override
	public boolean isTypeValid(int typeId) throws TypeNotFoundException {
		boolean valid = false;
		try {
			valid = typeObj.isTypeValid(typeId);
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return valid;
	}

}
