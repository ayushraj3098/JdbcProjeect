package service.Impl;

import java.util.Comparator;

import entity.Watch;

public class PriceComparator implements Comparator <Watch> {

	

	@Override
	public int compare(Watch o1, Watch o2) {
		if(o1.getPrice()>o2.getPrice())
			return 1;
		else 
		return -1;
	}

}
