package service.Impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

import dao.WatchDao;
import dao.Impl.WatchDaoImpl;
import entity.Watch;
import service.WatchService;

public class WatchServiceImpl implements WatchService {
	

	private static Scanner sc = new Scanner(System.in);
	WatchDao watch = new WatchDaoImpl();

	@Override
	public boolean addWatch(int typeId) throws SQLException {

		System.out.println("Enter following watch details: ");
		System.out.print("Id - ");
		int id = sc.nextInt();
		sc.nextLine();

		System.out.print("Model number - ");
		String modelNumber = sc.nextLine();

		System.out.print("Price - ");
		float price = sc.nextFloat();

		watch.addWatch(typeId, id, modelNumber, price);
		return false;
	}

	@Override
	public ArrayList<Watch> getAllWatches() throws SQLException {
		return watch.getAllWatches();
	}
	public ArrayList<Watch> sortWatches(ArrayList<Watch> watches) throws SQLException{
		 Collections.sort(watches, new PriceComparator());
		 return watches;
	}
}
