package service;

import java.sql.SQLException;
import java.util.ArrayList;

import entity.Watch;
import exception.TypeNotFoundException;

public interface WatchService {
	boolean addWatch(int typeId) throws SQLException;

	ArrayList<Watch> getAllWatches() throws SQLException;
	
	ArrayList<Watch> sortWatches(ArrayList<Watch> watches) throws SQLException;

}
