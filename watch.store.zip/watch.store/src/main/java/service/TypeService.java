package service;

import java.sql.SQLException;

import entity.Type;
import exception.TypeNotFoundException;
import exception.TypeServiceException;

public interface TypeService {
	
	boolean addType(Type type) throws SQLException, TypeServiceException;
	
	boolean isTypeValid(int typeId) throws  TypeNotFoundException;

}
